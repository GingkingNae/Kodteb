import cv2
import numpy as np
import os
import time
import pytesseract
from ultralytics import YOLO

# โหลดโมเดล AI (ต้องใส่ไฟล์โมเดล .pt ไว้ในโฟลเดอร์เดียวกัน)
model = YOLO("best_fish_model.pt")

def capture_screen():
    os.system("adb shell screencap -p /sdcard/screen.png")
    os.system("adb pull /sdcard/screen.png")
    return cv2.imread("screen.png")

def detect_fish(image):
    results = model(image)
    fishes = []
    for result in results:
        for box in result.boxes.xyxy:
            x1, y1, x2, y2 = map(int, box[:4])
            fishes.append((x1, y1, x2, y2))
    return fishes

def extract_health(image, x1, y1, x2, y2):
    fish_crop = image[y1:y2, x1:x2]
    gray = cv2.cvtColor(fish_crop, cv2.COLOR_BGR2GRAY)
    health_text = pytesseract.image_to_string(gray, config='--psm 6')
    return int(health_text) if health_text.isdigit() else 100

def select_best_target(fishes, image):
    min_health = 9999
    best_target = None
    for (x1, y1, x2, y2) in fishes:
        health = extract_health(image, x1, y1, x2, y2)
        if health < min_health:
            min_health = health
            best_target = (x1, y1)
    return best_target

def shoot_fish(x, y):
    cmd = f"adb shell input tap {x} {y}"
    os.system(cmd)

while True:
    screen = capture_screen()
    fishes = detect_fish(screen)
    if fishes:
        target = select_best_target(fishes, screen)
        if target:
            x, y = target
            shoot_fish(x, y)
    time.sleep(0.5)
